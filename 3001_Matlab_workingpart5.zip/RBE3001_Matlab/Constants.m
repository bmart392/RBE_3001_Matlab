% These are the robot constants that never change.

Link1 = 0.135; % The straight up link.
Link2 = 0.175; % The shoulder link.
Link3 = 0.16928; % The elbow link.

