function roses()
disp(toc);
end