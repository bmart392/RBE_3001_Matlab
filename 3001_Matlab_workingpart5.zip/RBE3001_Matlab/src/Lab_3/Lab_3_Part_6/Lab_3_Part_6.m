%% The files formerly found in this folder can now be
% found in /Utility_Function/Cubic_Trajectory_Generation