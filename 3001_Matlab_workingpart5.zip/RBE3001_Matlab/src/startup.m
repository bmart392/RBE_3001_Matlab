% This is the matlab script that adds all the files to the path that I
% specify. 

addpath 'Lab_4';