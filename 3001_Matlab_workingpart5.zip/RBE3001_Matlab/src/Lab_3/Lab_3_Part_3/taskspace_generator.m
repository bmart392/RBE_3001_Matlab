
% Here we are creating 2 arbitrary points in the task space.

function T = taskspace_generator()

% This function creates 3 random locations 

end